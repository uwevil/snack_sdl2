#include "defs.h"

extern SDL_Surface *screen;
