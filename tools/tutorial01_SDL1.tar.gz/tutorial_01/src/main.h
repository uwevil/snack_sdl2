#include "defs.h"

SDL_Surface *screen;
